import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Order submission endpoint
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.json({ success: true, order });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid order data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create order" });
      }
    }
  });

  // Get orders (for admin purposes)
  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Blog posts endpoint (for SEO content)
  app.get("/api/blog", async (req, res) => {
    try {
      const posts = await storage.getAllBlogPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  // AI Chat endpoint (basic implementation)
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      // Basic keyword-based responses
      let response = "Thank you for your message! For immediate assistance, please contact us via WhatsApp at +1 843 595 1655, or fill out our order form for a detailed quote.";
      
      if (message.toLowerCase().includes("price") || message.toLowerCase().includes("cost")) {
        response = "Our pricing starts at $15 per page for regular orders (7+ days), $20 for urgent orders (1-6 days), and $25 for very urgent orders (≤24 hours). Please use our order form for an exact quote!";
      } else if (message.toLowerCase().includes("essay") || message.toLowerCase().includes("paper")) {
        response = "We offer professional essay and research paper writing services across all academic levels. Our expert writers can help with any subject. Would you like to place an order?";
      } else if (message.toLowerCase().includes("deadline") || message.toLowerCase().includes("urgent")) {
        response = "We can handle urgent orders with deadlines as short as 3 hours! The pricing varies based on urgency. Please fill out our order form to get started.";
      }

      res.json({ response });
    } catch (error) {
      res.status(500).json({ error: "Chat service unavailable" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
