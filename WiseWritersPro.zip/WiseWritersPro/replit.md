# WiseWriters - Academic Writing Services Platform

## Overview

WiseWriters is a full-stack web application providing academic writing services. The platform allows students to submit orders for essays, research papers, and other academic assignments through an intuitive interface. Built with a modern React frontend and Express.js backend, the application features order management, blog content for SEO, and WhatsApp integration for customer communication.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution
- **Production Build**: esbuild for fast bundling

### Database Strategy
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema**: Shared schema definitions between client and server
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Core Services
1. **Order Management System**
   - Order form with real-time price calculation
   - Validation using Zod schemas
   - WhatsApp integration for order notifications
   - File upload support for additional materials

2. **Content Management**
   - Blog system for SEO content
   - Static testimonials and service descriptions
   - FAQ section with expandable content

3. **User Interface**
   - Responsive design with mobile-first approach
   - Interactive chat widget for customer support
   - Modern hero section with clear call-to-actions
   - Service showcase with detailed descriptions

### Technical Components
1. **Form System**: Robust form handling with validation and error management
2. **File Handling**: Support for file uploads in order submissions
3. **Price Calculator**: Dynamic pricing based on urgency, pages, and academic level
4. **Communication**: WhatsApp API integration for instant customer contact

## Data Flow

1. **Order Submission Flow**:
   - User fills order form → Client validation → Server validation → Database storage → WhatsApp notification

2. **Content Delivery Flow**:
   - Client requests → Express server → Static content/API responses → Client rendering

3. **Blog Content Flow**:
   - Server stores blog posts → API endpoints → Client consumption for SEO

## External Dependencies

### Core Dependencies
- **UI Framework**: React with extensive Radix UI component collection
- **Database**: @neondatabase/serverless for PostgreSQL connectivity
- **Validation**: Zod for runtime type checking and validation
- **Forms**: React Hook Form with resolver integration
- **Styling**: Tailwind CSS with PostCSS processing

### Development Tools
- **Build**: Vite with React plugin and runtime error overlay
- **Database**: Drizzle Kit for schema management
- **TypeScript**: Full type safety across the stack
- **Linting**: ESLint configuration for code quality

### External Services
- **WhatsApp Business API**: For order notifications and customer communication
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit**: Development and deployment platform

## Deployment Strategy

### Development Environment
- **Runtime**: Node.js 20 with PostgreSQL 16
- **Hot Reload**: Vite dev server with HMR support
- **Database**: Local PostgreSQL instance for development

### Production Deployment
- **Platform**: Replit with autoscale deployment target
- **Build Process**: Two-stage build (frontend Vite build + backend esbuild)
- **Static Assets**: Frontend builds to dist/public, served by Express
- **Environment**: Production optimizations with asset compression

### Configuration Management
- **Environment Variables**: DATABASE_URL for database connection
- **Port Configuration**: Port 5000 for development, port 80 for production
- **Asset Serving**: Express serves built frontend assets in production

## Changelog
- June 21, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.