import { useState } from "react";
import { Button } from "@/components/ui/button";
import OrderForm from "./order-form";
import { MessageCircle, Menu, X } from "lucide-react";

export default function Header() {
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-primary">WiseWriters</h1>
              </div>
            </div>
            
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <button 
                  onClick={() => scrollToSection('services')}
                  className="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Services
                </button>
                <button 
                  onClick={() => scrollToSection('how-it-works')}
                  className="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  How It Works
                </button>
                <button 
                  onClick={() => scrollToSection('testimonials')}
                  className="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Reviews
                </button>
                <button 
                  onClick={() => scrollToSection('blog')}
                  className="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Blog
                </button>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <a 
                href="https://wa.me/18435951655" 
                className="hidden sm:flex items-center bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                +1 843 595 1655
              </a>
              
              <Button 
                onClick={() => setShowOrderForm(true)}
                className="bg-primary hover:bg-blue-700 text-white px-6 py-2 rounded-lg text-sm font-medium transition duration-200"
              >
                Order Now
              </Button>
              
              <button 
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
                <button 
                  onClick={() => scrollToSection('services')}
                  className="block text-gray-600 hover:text-primary px-3 py-2 text-base font-medium w-full text-left"
                >
                  Services
                </button>
                <button 
                  onClick={() => scrollToSection('how-it-works')}
                  className="block text-gray-600 hover:text-primary px-3 py-2 text-base font-medium w-full text-left"
                >
                  How It Works
                </button>
                <button 
                  onClick={() => scrollToSection('testimonials')}
                  className="block text-gray-600 hover:text-primary px-3 py-2 text-base font-medium w-full text-left"
                >
                  Reviews
                </button>
                <button 
                  onClick={() => scrollToSection('blog')}
                  className="block text-gray-600 hover:text-primary px-3 py-2 text-base font-medium w-full text-left"
                >
                  Blog
                </button>
                <a 
                  href="https://wa.me/18435951655" 
                  className="flex items-center bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-lg text-base font-medium transition duration-200 mx-3 mt-2"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  +1 843 595 1655
                </a>
              </div>
            </div>
          )}
        </nav>
      </header>

      <OrderForm 
        isOpen={showOrderForm} 
        onClose={() => setShowOrderForm(false)} 
      />
    </>
  );
}
