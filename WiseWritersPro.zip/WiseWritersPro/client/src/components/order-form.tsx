import { useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X, Upload, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { sendOrderToWhatsApp } from "@/lib/whatsapp";
import { useToast } from "@/hooks/use-toast";

const orderSchema = z.object({
  subject: z.string().min(1, "Subject is required"),
  academicLevel: z.string().min(1, "Academic level is required"),
  deadline: z.string().min(1, "Deadline is required"),
  pages: z.number().min(1, "Pages must be at least 1"),
  instructions: z.string().min(10, "Instructions must be at least 10 characters"),
});

type OrderFormData = z.infer<typeof orderSchema>;

interface OrderFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OrderForm({ isOpen, onClose }: OrderFormProps) {
  const [estimatedPrice, setEstimatedPrice] = useState(0);
  const [files, setFiles] = useState<FileList | null>(null);
  const { toast } = useToast();

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      subject: "",
      academicLevel: "",
      deadline: "",
      pages: 1,
      instructions: "",
    },
  });

  const calculatePrice = useCallback((deadline: string, pages: number) => {
    let pricePerPage = 15; // Regular

    if (deadline.includes("hour") || deadline === "1-day") {
      pricePerPage = 25; // Very urgent
    } else if (deadline === "3-days" || deadline === "12-hours") {
      pricePerPage = 20; // Urgent
    }

    return pricePerPage * pages;
  }, []);

  const handleDeadlineChange = (deadline: string) => {
    const pages = form.getValues("pages");
    if (pages) {
      const price = calculatePrice(deadline, pages);
      setEstimatedPrice(price);
    }
  };

  const handlePagesChange = (pages: number) => {
    const deadline = form.getValues("deadline");
    if (deadline) {
      const price = calculatePrice(deadline, pages);
      setEstimatedPrice(price);
    }
  };

  const onSubmit = async (data: OrderFormData) => {
    try {
      const orderData = {
        ...data,
        estimatedPrice,
        files: files ? Array.from(files).map(file => file.name) : [],
      };

      await sendOrderToWhatsApp(orderData);
      
      toast({
        title: "Order Submitted!",
        description: "Your order has been sent via WhatsApp. We'll contact you soon!",
      });

      form.reset();
      setEstimatedPrice(0);
      setFiles(null);
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit order. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFiles(e.target.files);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900">Place Your Order</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject/Course</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Subject" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="english">English Literature</SelectItem>
                        <SelectItem value="history">History</SelectItem>
                        <SelectItem value="psychology">Psychology</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="nursing">Nursing</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="academicLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Academic Level</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="high-school">High School</SelectItem>
                        <SelectItem value="college">College</SelectItem>
                        <SelectItem value="university">University</SelectItem>
                        <SelectItem value="masters">Master's</SelectItem>
                        <SelectItem value="phd">PhD</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="deadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deadline</FormLabel>
                    <Select 
                      onValueChange={(value) => {
                        field.onChange(value);
                        handleDeadlineChange(value);
                      }} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Deadline" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="3-hours">3 Hours</SelectItem>
                        <SelectItem value="6-hours">6 Hours</SelectItem>
                        <SelectItem value="12-hours">12 Hours</SelectItem>
                        <SelectItem value="1-day">1 Day</SelectItem>
                        <SelectItem value="3-days">3 Days</SelectItem>
                        <SelectItem value="7-days">7 Days</SelectItem>
                        <SelectItem value="14-days">14 Days</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="pages"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pages / Word Count</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        placeholder="Number of pages"
                        {...field}
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          field.onChange(value);
                          handlePagesChange(value);
                        }}
                      />
                    </FormControl>
                    <p className="text-xs text-gray-500">1 page = ~275 words</p>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="instructions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Instructions</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Provide detailed instructions for your assignment..."
                      className="h-32"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">File Upload (Optional)</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600 mb-2">Drag and drop files here or click to browse</p>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  Choose Files
                </Button>
                {files && files.length > 0 && (
                  <div className="mt-2 text-sm text-gray-600">
                    {Array.from(files).map((file, index) => (
                      <div key={index}>{file.name}</div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Pricing Display */}
            <div className="bg-slate-50 rounded-lg p-6 border">
              <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                <DollarSign className="w-5 h-5 mr-2" />
                Pricing Guidelines
              </h4>
              <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                <div className="text-center">
                  <div className="text-secondary font-bold text-lg">$15</div>
                  <div className="text-gray-600">Regular<br />(7+ days)</div>
                </div>
                <div className="text-center">
                  <div className="text-orange-500 font-bold text-lg">$20</div>
                  <div className="text-gray-600">Urgent<br />(1-6 days)</div>
                </div>
                <div className="text-center">
                  <div className="text-red-600 font-bold text-lg">$25</div>
                  <div className="text-gray-600">Very Urgent<br />(≤24 hours)</div>
                </div>
              </div>
              <div className="p-3 bg-white rounded border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Estimated Total:</span>
                  <span className="text-xl font-bold text-primary">${estimatedPrice}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1 bg-secondary hover:bg-green-600">
                Submit Order via WhatsApp
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
