import { Button } from "@/components/ui/button";
import { 
  PenTool, 
  Search, 
  Edit, 
  Briefcase, 
  Film, 
  Bookmark, 
  BookOpen, 
  TrendingUp, 
  Lightbulb, 
  Presentation, 
  GraduationCap, 
  FlipHorizontal2 
} from "lucide-react";
import { useState } from "react";
import OrderForm from "./order-form";

const services = [
  { icon: PenTool, title: "Essay Writing", description: "Professional essay writing services for all academic levels and subjects." },
  { icon: Search, title: "Research Assistance", description: "Comprehensive research support and data analysis for academic projects." },
  { icon: Edit, title: "Editing & Proofreading", description: "Professional editing and proofreading to perfect your academic work." },
  { icon: Briefcase, title: "Case Studies", description: "In-depth case study analysis and writing for business and academic needs." },
  { icon: Film, title: "Book/Movie Reviews", description: "Critical reviews and analysis of literature, films, and media content." },
  { icon: Bookmark, title: "Annotated Bibliographies", description: "Comprehensive annotated bibliographies with critical source analysis." },
  { icon: BookOpen, title: "Literature Reviews", description: "Systematic literature reviews and critical analysis of academic sources." },
  { icon: TrendingUp, title: "Business Plans", description: "Professional business plan development and financial projections." },
  { icon: Lightbulb, title: "Research Proposals", description: "Well-structured research proposals for thesis and dissertation projects." },
  { icon: Presentation, title: "Presentations", description: "Engaging presentations and speeches for academic and professional use." },
  { icon: GraduationCap, title: "Admission Essays", description: "Compelling admission essays for college and graduate school applications." },
  { icon: FlipHorizontal2, title: "Reflective Writing", description: "Personal reflection papers and self-assessment assignments." }
];

export default function ServicesSection() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  return (
    <>
      <section id="services" className="bg-slate-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Academic Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional writing assistance across all academic disciplines and assignment types
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition duration-200 border border-gray-100"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mr-4">
                    <service.icon className="text-primary w-6 h-6" />
                  </div>
                  <h3 className="font-semibold text-gray-900">{service.title}</h3>
                </div>
                <p className="text-gray-600 text-sm">{service.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              onClick={() => setShowOrderForm(true)}
              className="bg-primary hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition duration-200"
              size="lg"
            >
              Get Started Today
            </Button>
          </div>
        </div>
      </section>

      <OrderForm 
        isOpen={showOrderForm} 
        onClose={() => setShowOrderForm(false)} 
      />
    </>
  );
}
