import { Button } from "@/components/ui/button";
import { Clock, Shield, GraduationCap } from "lucide-react";
import { useState } from "react";
import OrderForm from "./order-form";

export default function HeroSection() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  return (
    <>
      <section className="gradient-hero text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
                Expert Academic Writing Services You Can Trust
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Get professional help with essays, research papers, and assignments from qualified writers. 
                Guaranteed quality, on-time delivery, and 24/7 support.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  onClick={() => setShowOrderForm(true)}
                  className="bg-secondary hover:bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition duration-200"
                  size="lg"
                >
                  Order Now
                </Button>
                <Button 
                  onClick={() => setShowOrderForm(true)}
                  variant="outline"
                  className="border-2 border-white hover:bg-white hover:text-primary text-white px-8 py-4 rounded-lg text-lg font-semibold transition duration-200"
                  size="lg"
                >
                  Get a Quote
                </Button>
              </div>
              <div className="flex flex-wrap items-center gap-6 text-sm">
                <div className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-200" />
                  <span>24/7 Support</span>
                </div>
                <div className="flex items-center">
                  <Shield className="w-5 h-5 mr-2 text-blue-200" />
                  <span>100% Original</span>
                </div>
                <div className="flex items-center">
                  <GraduationCap className="w-5 h-5 mr-2 text-blue-200" />
                  <span>PhD Writers</span>
                </div>
              </div>
            </div>
            <div className="lg:text-right">
              <img 
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Students studying together in library" 
                className="rounded-xl shadow-2xl w-full max-w-md mx-auto lg:mx-0 lg:ml-auto" 
              />
            </div>
          </div>
        </div>
      </section>

      <OrderForm 
        isOpen={showOrderForm} 
        onClose={() => setShowOrderForm(false)} 
      />
    </>
  );
}
