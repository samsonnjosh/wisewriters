import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah M.",
    degree: "Psychology Major",
    initials: "SM",
    rating: 5,
    text: "Excellent work! The writer delivered exactly what I needed for my research paper. The quality exceeded my expectations and it was delivered ahead of schedule."
  },
  {
    name: "Michael J.",
    degree: "MBA Student", 
    initials: "MJ",
    rating: 5,
    text: "WiseWriters saved my semester! Their thesis writing service is top-notch. Professional, responsive, and delivered quality work that helped me graduate with honors."
  },
  {
    name: "Emily L.",
    degree: "PhD Candidate",
    initials: "EL", 
    rating: 5,
    text: "Amazing service! The editing and proofreading team transformed my dissertation. Clear communication throughout the process and exceptional attention to detail."
  }
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="bg-slate-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
          <p className="text-xl text-gray-600">Trusted by thousands of students worldwide</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 text-sm">{testimonial.rating}.0</span>
              </div>
              <p className="text-gray-700 mb-6">"{testimonial.text}"</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center mr-4">
                  <span className="text-gray-600 font-semibold">{testimonial.initials}</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-gray-600 text-sm">{testimonial.degree}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <div className="inline-flex items-center bg-white rounded-lg px-6 py-4 shadow-sm border border-gray-100">
            <div className="flex text-yellow-400 mr-3">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-current" />
              ))}
            </div>
            <div className="text-left">
              <p className="text-2xl font-bold text-gray-900">4.9/5</p>
              <p className="text-gray-600">Based on 2,547+ reviews</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
