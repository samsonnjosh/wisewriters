import { Calendar, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const blogPosts = [
  {
    title: "10 Essential Tips for Writing Outstanding Research Papers",
    excerpt: "Discover the key strategies that professional academic writers use to create compelling and well-structured research papers...",
    category: "Writing Tips",
    date: "Dec 15, 2024",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
  },
  {
    title: "How to Choose the Right Citation Style for Your Assignment",
    excerpt: "Understanding when to use APA, MLA, Chicago, or Harvard citation styles can make or break your academic paper...",
    category: "Academic Success",
    date: "Dec 12, 2024",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
  },
  {
    title: "Thesis Writing: A Complete Step-by-Step Guide",
    excerpt: "From choosing your research topic to defending your thesis, this comprehensive guide covers everything you need to know...",
    category: "Thesis Writing",
    date: "Dec 10, 2024",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
  }
];

export default function BlogSection() {
  return (
    <section id="blog" className="bg-slate-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Latest from Our Blog</h2>
          <p className="text-xl text-gray-600">Tips, guides, and insights for academic success</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <article key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition duration-200">
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-48 object-cover" 
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{post.date}</span>
                  <span className="mx-2">•</span>
                  <span>{post.category}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{post.title}</h3>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <button className="text-primary hover:text-blue-700 font-medium transition-colors">
                  Read More →
                </button>
              </div>
            </article>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button 
            className="bg-primary hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition duration-200"
            size="lg"
          >
            View All Articles
          </Button>
        </div>
      </div>
    </section>
  );
}
