import { useState } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "👋 Hi! How can I help you with your academic writing needs today?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const sendMessage = () => {
    if (!message.trim()) return;

    const newMessage = {
      id: messages.length + 1,
      text: message,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages([...messages, newMessage]);
    setMessage("");

    // Simulate bot response
    setTimeout(() => {
      const botResponse = {
        id: messages.length + 2,
        text: "Thank you for your message! For immediate assistance, please contact us via WhatsApp at +1 843 595 1655, or fill out our order form for a detailed quote.",
        isBot: true,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 1000);
  };

  const quickMessage = (msg: string) => {
    setMessage(msg);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <div
        className={`bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center cursor-pointer shadow-lg hover:bg-blue-700 transition duration-200 ${
          isOpen ? "hidden" : "block"
        }`}
        onClick={toggleChat}
      >
        <MessageCircle className="w-6 h-6" />
      </div>

      {isOpen && (
        <div className="absolute bottom-20 right-0 w-80 bg-white rounded-lg shadow-xl border border-gray-200">
          <div className="bg-primary text-white p-4 rounded-t-lg">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="font-semibold">WiseWriters Support</h4>
                <p className="text-sm text-blue-100">Typically replies instantly</p>
              </div>
              <button onClick={toggleChat} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-4 h-64 overflow-y-auto bg-gray-50 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`${
                  msg.isBot
                    ? "bg-white p-3 rounded-lg shadow-sm border border-gray-100 mr-8"
                    : "bg-primary text-white p-3 rounded-lg ml-8"
                }`}
              >
                <p className="text-sm">{msg.text}</p>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2 mb-3">
              <Input
                type="text"
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1"
              />
              <Button onClick={sendMessage} size="sm">
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex justify-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickMessage("I need help with an essay")}
                className="text-xs"
              >
                Essay Help
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickMessage("What are your prices?")}
                className="text-xs"
              >
                Pricing
              </Button>
              <Button size="sm" className="bg-green-500 hover:bg-green-600 text-xs">
                <a
                  href="https://wa.me/18435951655"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center"
                >
                  <MessageCircle className="w-3 h-3 mr-1" />
                  WhatsApp
                </a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
