import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

const faqs = [
  {
    question: "How do you ensure original, plagiarism-free content?",
    answer: "All our academic papers are written from scratch by qualified writers. We use advanced plagiarism detection software and provide free plagiarism reports with every order to ensure 100% originality."
  },
  {
    question: "What qualifications do your essay writers have?",
    answer: "Our academic writing team consists of PhD holders, Masters graduates, and experienced professionals with expertise in various academic disciplines. All writers undergo rigorous screening and testing before joining our team."
  },
  {
    question: "Do you offer revisions for research papers and assignments?",
    answer: "Yes! We offer unlimited free revisions within 14 days of delivery. Our goal is your complete satisfaction with the final academic work, and we'll make adjustments until you're happy with the results."
  },
  {
    question: "How quickly can you complete urgent assignments?",
    answer: "We can handle urgent orders with deadlines as short as 3 hours for shorter assignments. For longer papers like dissertations or thesis work, we recommend allowing more time to ensure the highest quality results."
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="bg-white py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600">Everything you need to know about our academic writing services</p>
        </div>
        
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gray-200 rounded-lg">
              <button 
                className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                onClick={() => toggleFAQ(index)}
              >
                <span className="font-semibold text-gray-900">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-600">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
