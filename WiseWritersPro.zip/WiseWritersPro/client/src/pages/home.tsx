import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import ServicesSection from "@/components/services-section";
import TestimonialsSection from "@/components/testimonials-section";
import FAQSection from "@/components/faq-section";
import BlogSection from "@/components/blog-section";
import Footer from "@/components/footer";
import ChatWidget from "@/components/chat-widget";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <HeroSection />
      
      {/* Tagline Section */}
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Your #1 Paper Writing Service
          </h2>
          <p className="text-xl text-gray-600">
            Our expert essay writers can tackle any academic task you entrust them with.
          </p>
        </div>
      </section>

      <ServicesSection />
      
      {/* How It Works Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Simple, fast, and reliable process</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Place Your Order</h3>
              <p className="text-gray-600">Fill out our simple order form with your requirements and upload any necessary files.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Expert Assignment</h3>
              <p className="text-gray-600">We match your project with the most qualified writer in your field of study.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Receive Quality Work</h3>
              <p className="text-gray-600">Get your completed assignment on time, ready for submission with free revisions included.</p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <img 
              src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Professional writer working in modern office" 
              className="rounded-xl shadow-lg mx-auto max-w-4xl w-full" 
            />
          </div>
        </div>
      </section>

      <TestimonialsSection />
      <FAQSection />
      <BlogSection />
      <Footer />
      <ChatWidget />
    </div>
  );
}
