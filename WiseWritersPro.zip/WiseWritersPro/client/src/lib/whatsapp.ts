interface OrderData {
  subject: string;
  academicLevel: string;
  deadline: string;
  pages: number;
  instructions: string;
  estimatedPrice: number;
  files?: string[];
}

export async function sendOrderToWhatsApp(orderData: OrderData): Promise<void> {
  const message = `
🎓 *New Order from WiseWriters*

📚 *Subject:* ${orderData.subject}
🎯 *Academic Level:* ${orderData.academicLevel}
⏰ *Deadline:* ${orderData.deadline}
📄 *Pages:* ${orderData.pages}

📝 *Instructions:*
${orderData.instructions}

💰 *Estimated Price:* $${orderData.estimatedPrice}

${orderData.files && orderData.files.length > 0 ? `📎 *Attached Files:* ${orderData.files.join(', ')}` : ''}

Please confirm this order and provide payment details.
  `.trim();

  const whatsappURL = `https://wa.me/18435951655?text=${encodeURIComponent(message)}`;
  window.open(whatsappURL, '_blank');
}
